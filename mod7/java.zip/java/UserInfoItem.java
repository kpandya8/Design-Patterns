public class UserInfoItem {

}
