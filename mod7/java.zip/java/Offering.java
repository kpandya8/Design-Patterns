public class Offering {

	private OfferingList offeringList;

}
