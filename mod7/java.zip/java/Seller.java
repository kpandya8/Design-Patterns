/**
 * The concrete implementation of the Person class.
 */
public class Seller extends Person {

	/**
	 * According to the need of seller show the appropriate items on the menu. 
	 */
	public void showMenu() {

	}

	/**
	 * According to the Product type create a concrete product menu: 
	 * meat or produce. 
	 */
	public ProductMenu CreateProductMenu() {
		return null;
	}

}
