public class Product {

	private ClassProductList classProductList;

	private Trading trading;

}
