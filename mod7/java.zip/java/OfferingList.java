/**
 * Subclass of ArrayList. One concreted List class that needs to be iterated.
 */
public class OfferingList extends ArrayList {

	private OfferingIterator offeringIterator;

	private Trading trading;

	private Offering[] offering;

}
