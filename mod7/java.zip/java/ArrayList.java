/**
 * The abstract class of the list to be iterated. [Built into Java] 
 */
public abstract class ArrayList {

}
