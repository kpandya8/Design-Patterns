/**
 * A subclass of ProductMenu. One of the concrete products of the factor 
 * method. 
 */
public class ProduceProductMenu extends ProductMenu {

	public void showMenu() {

	}

	/**
	 * To show the add buttons.
	 */
	public void showAddButton() {

	}

	/**
	 * To show the radio buttons. 
	 */
	public void showRadioButton() {

	}

	/**
	 * To show the labels. 
	 */
	public void showLabels() {

	}

	/**
	 * To show the view buttons. 
	 */
	public void showViewButton() {

	}

	public void showComboxes() {

	}

}
