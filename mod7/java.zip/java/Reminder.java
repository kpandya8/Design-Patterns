/**
 * The client of the visitor pattern. This class will use the visitor to visit all the 
 * products and trading of a given user. 
 */
public class Reminder {

}
