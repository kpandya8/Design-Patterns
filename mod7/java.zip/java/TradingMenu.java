public class TradingMenu {

}
